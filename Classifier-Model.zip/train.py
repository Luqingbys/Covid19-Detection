from torch.utils.data import random_split
from utils.SoundDS import SoundDS
import pandas as pd
from pathlib import Path
import torch
from torch import nn
import torchaudio
from model.resNet import ResNet

# ----------------------------
# Training Loop
# ----------------------------
def training(model: nn.Module, train_dl, num_epochs):
    # 损失函数使用交叉熵
    criterion = nn.CrossEntropyLoss()
    # 优化器使用Adam
    optimizer = torch.optim.Adam(model.parameters(),lr=0.001)
    scheduler = torch.optim.lr_scheduler.OneCycleLR(optimizer, max_lr=0.001,
                                                steps_per_epoch=int(len(train_dl)),
                                                epochs=num_epochs,
                                                anneal_strategy='linear')
    # Repeat for each epoch，开始迭代训练
    for epoch in range(num_epochs):
        running_loss = 0.0
        correct_prediction = 0
        total_prediction = 0

        for i, data in enumerate(train_dl):
            # inputs, labels = data[0].to(device), data[1].to(device)
            inputs: torch.Tensor
            labels: torch.Tensor 
            inputs, labels = data[0], data[1]
            # print(inputs.shape, inputs) # inputs: (16, 2, h, w)
            
            inputs_m, inputs_s = inputs.mean(), inputs.std()
            inputs = (inputs - inputs_m) / inputs_s

            optimizer.zero_grad()
            # 经过模型计算出来的结果，是一个二维向量
            outputs = model(inputs)
            loss = criterion(outputs, labels)
            # 反向传播
            loss.backward()
            optimizer.step()
            scheduler.step()
            running_loss += loss.item()


            _, prediction = torch.max(outputs,1)

            correct_prediction += (prediction == labels).sum().item()
            total_prediction += prediction.shape[0]

            # if i % 10 == 0:
                # print('[%d, %5d] loss: %.3f' % (epoch + 1, i + 1, running_loss / 10))
    
        num_batches = len(train_dl)
        avg_loss = running_loss / num_batches
        acc = correct_prediction/total_prediction
        print(f'Epoch: {epoch}, Loss: {avg_loss:.2f}, Accuracy: {acc:.2f}')
        
    print('Finished Training')


# 读取训练集文件路径
metadata_file = 'G:\深度学习\小项目\新冠检测\Classifier-Model\\train.csv'
data_path = './data/train/'
df = pd.read_csv(metadata_file)
# df = pd.read_csv('./data/train.csv')
# df.head()

myds = SoundDS(df, data_path)
print("dataset: ", myds)

num_items = len(myds)
print("number: ", num_items)
# 训练集和验证集以4:1进行分割
num_train = round(num_items * 0.8)
num_val = num_items - num_train
# 将myds数据集随机划分为训练集和验证集
train_ds, val_ds = random_split(myds, [num_train, num_val])

# 得到训练集和验证集的数据加载器
train_dl = torch.utils.data.DataLoader(train_ds, batch_size=16, shuffle=True)
val_dl = torch.utils.data.DataLoader(val_ds, batch_size=16, shuffle=False)
print(train_dl)

# 测试读取音频文件
# pathstr = './train/0a2c9a6e-94fd-4a2a-a256-aee9140ef587.wav'
# res1 = torchaudio.load(pathstr)
# print(res1)

model = ResNet()
training(model=model, train_dl=train_dl, num_epochs=10)